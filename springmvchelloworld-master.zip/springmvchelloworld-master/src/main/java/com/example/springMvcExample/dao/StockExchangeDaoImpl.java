package com.example.springMvcExample.dao;

public class StockExchangeDaoImpl {

}
