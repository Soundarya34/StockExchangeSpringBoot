package com.example.springMvcExample.dao;

public interface StockExchangeDao {

}
