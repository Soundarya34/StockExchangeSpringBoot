package com.example.springMvcExample.service;

public interface StockExchangeService {

}
