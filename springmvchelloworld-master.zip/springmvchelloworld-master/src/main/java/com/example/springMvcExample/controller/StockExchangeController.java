package com.example.springMvcExample.controller;

public interface StockExchangeController {

}
